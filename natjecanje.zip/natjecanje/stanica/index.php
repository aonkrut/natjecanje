<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stanica</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<form action="kamera.php" method="POST">
    <div class="mb-3">
    <input type="hidden" name="stanica_id" value="<?php echo $stanica_id; ?>">
        <label for="stanica_id" class="form-label">Odaberite stanica:</label>
        <select class="form-select" id="stanica_id" name="stanica_id" required>
            <?php
            // Uspostavljanje veze s bazom podataka
            include '../spajanje.php'; // Sadrži $conn = new mysqli(...)
            // Dohvaćanje svih stanica iz baze podataka
            $staniceQuery = "SELECT * FROM stanice";
            $staniceResult = $conn->query($staniceQuery);

            // Prikazivanje opcija u padajućem izborniku
            while ($row = $staniceResult->fetch_assoc()) {
                echo "<option value='" . $row['id'] . "'>" . $row['naziv'] . "</option>";
                
            }
            ?>
        </select>
    </div>
    <div class="mb-3">
        <label for="lozinka" class="form-label">Unesite lozinku:</label>
        <input type="password" class="form-control" id="lozinka" name="lozinka" required>
    </div>
    <button type="submit" class="btn btn-primary">Spremi i nastavi</button>
</form>

</body>
</html>
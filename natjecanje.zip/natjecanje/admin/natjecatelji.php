<?php
include '../spajanje.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM natjecatelji WHERE id = $id";
    $result = $conn->query($query);
    $natjecatelj = $result->fetch_assoc();
} else {
    $natjecatelj = null;
}
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uredi Natjecatelja</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1><?php echo $natjecatelj ? 'Uredi Natjecatelja' : 'Dodaj Novog Natjecatelja'; ?></h1>
    <form action="akcije.php" method="POST">
        <input type="hidden" name="action" value="<?php echo $natjecatelj ? 'editNatjecatelj' : 'addNatjecatelj'; ?>">
        <?php if ($natjecatelj) { ?>
            <input type="hidden" name="id" value="<?php echo $natjecatelj['id']; ?>">
        <?php } ?>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo $natjecatelj ? $natjecatelj['email'] : ''; ?>" required>
        </div>
        <div class="mb-3">
            <label for="ime" class="form-label">Ime</label>
            <input type="text" class="form-control" id="ime" name="ime" value="<?php echo $natjecatelj ? $natjecatelj['ime'] : ''; ?>" required>
        </div>
        <div class="mb-3">
            <label for="prezime" class="form-label">Prezime</label>
            <input type="text" class="form-control" id="prezime" name="prezime" value="<?php echo $natjecatelj ? $natjecatelj['prezime'] : ''; ?>" required>
        </div>
        <div class="mb-3">
            <label for="god_rodenja" class="form-label">Godina Rođenja</label>
            <input type="number" class="form-control" id="god_rodenja" name="god_rodenja" value="<?php echo $natjecatelj ? $natjecatelj['god_rodenja'] : ''; ?>" required>
        </div>
        <div class="mb-3">
            <label for="klub" class="form-label">Klub</label>
            <input type="text" class="form-control" id="klub" name="klub" value="<?php echo $natjecatelj ? $natjecatelj['klub'] : ''; ?>">
        </div>
        <div class="mb-3">
            <label for="kategorija" class="form-label">Kategorija</label>
            <select class="form-control" id="kategorija" name="kategorija">
               <?php 
                //spajanje na bazu i dohvaćanje kategorija iz baze
                include '../spajanje.php';
                $query = "SELECT * FROM kategorije";
                $result = $conn->query($query);
                while($row = $result->fetch_assoc()) {
                    echo "<option value='".$row['id']."'>".$row['naziv']."</option>";
                }
                
               ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="slika_putanja" class="form-label">Slika Putanja</label>
            <input type="text" class="form-control" id="slika_putanja" name="slika_putanja" value="<?php echo $natjecatelj ? $natjecatelj['slika_putanja'] : ''; ?>">
        </div>
        <button type="submit" class="btn btn-primary"><?php echo $natjecatelj ? 'Spremi Promjene' : 'Dodaj Natjecatelja'; ?></button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0/js/bootstrap.min.js"></script>
</body>
</html>

<?php $conn->close(); ?>

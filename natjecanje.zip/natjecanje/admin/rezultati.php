<?php
include '../spajanje.php';

// Provjeri je li poslan ID natjecanja putem GET zahtjeva
if(isset($_GET['natjecanje_id'])) {
    $natjecanjeId = $_GET['natjecanje_id'];

    // Dohvati početak utrke iz natjecanja
    $natjecanjaQuery = "SELECT naziv, vrijeme_starta FROM natjecanje WHERE id=$natjecanjeId";
    $natjecanjeResult = $conn->query($natjecanjaQuery);

    if ($natjecanjeResult->num_rows > 0) {
        $natjecanjeRow = $natjecanjeResult->fetch_assoc();
        $nazivNatjecanja = $natjecanjeRow['naziv'];
        $vrijemeStarta = $natjecanjeRow['vrijeme_starta'];

        echo "<h2>$nazivNatjecanja</h2>";
        echo "<h3>Vrijeme starta: $vrijemeStarta</h3>";
    }

    // Provjeri je li dohvaćeno vrijeme starta
    if(isset($vrijemeStarta)) {
        $vrijemeStartaTimestamp = strtotime($vrijemeStarta);
        
        // Dohvati stanice koje sudjeluju u natjecanju
        $staniceQuery = "SELECT * FROM stanice WHERE natjecanje_id = $natjecanjeId";
        $staniceResult = $conn->query($staniceQuery);
        
        if($staniceResult->num_rows > 0) {
            echo "<table border='1'>
                    <tr>
                        <th>Mjesto</th>
                        <th>Natjecatelj</th>
                        <th>Stanica ID</th>
                        <th>Vrijeme Potvrde</th>
                        <th>Rezultat (vrijeme)</th>
                    </tr>";
            $mjesto=0;
            // Iteriraj kroz sve stanice natjecanja
            while($stanica = $staniceResult->fetch_assoc()) {
                $stanicaId = $stanica['id'];

                // Dohvati rezultate za svakog natjecatelja za trenutnu stanicu
                $rezultatiQuery = "SELECT * FROM rezultati WHERE stanica_id = $stanicaId";
                $rezultatiResult = $conn->query($rezultatiQuery);
                
                if($rezultatiResult->num_rows > 0) {
                    // Inicijaliziraj asocijativno polje za praćenje najboljeg vremena svakog natjecatelja
                    $najbolje_vrijeme = array();
                    
                    while($rezultati = $rezultatiResult->fetch_assoc()) {
                        $natjecateljId = $rezultati['natjecatelj_id'];
                        $vp = $rezultati['vrijeme_potvrde'];
                        // Pretvori vrijeme potvrde u sate i minute
                        list($hours, $minutes, $seconds) = explode(':', $vp);
                        $vp_timestamp = strtotime($hours . ' hours ' . $minutes . ' minutes');
                        $vrijeme_potvrde = strtotime($rezultati['vrijeme_potvrde']);

                        // Provjeri je li trenutno vrijeme potvrde bolje od dosadašnjeg najboljeg za ovog natjecatelja
                        if(!isset($najbolje_vrijeme[$natjecateljId]) || $vrijeme_potvrde < $najbolje_vrijeme[$natjecateljId]) {
                            $najbolje_vrijeme[$natjecateljId] = $vrijeme_potvrde;
                        }
                    }
                    
                    // Ispis rezultata u tablicu za svakog natjecatelja
                    foreach($najbolje_vrijeme as $natjecateljId => $vrijemePotvrde) {
                        // Dohvati podatke o natjecatelju
                        $natjecateljQuery = "SELECT ime, prezime FROM natjecatelji WHERE id = $natjecateljId";
                        $natjecateljResult = $conn->query($natjecateljQuery);
                        $natjecatelj = $natjecateljResult->fetch_assoc();
                        $ime = $natjecatelj['ime'];
                        $prezime = $natjecatelj['prezime'];

                        // Izračunaj trajanje vremena natjecatelja
                        $trajanje = $vrijemePotvrde - $vrijemeStartaTimestamp;
                        $trajanjeFormatirano = gmdate("H:i:s", $trajanje);
                        $mjesto +=1;
                        // Ispis rezultata u tablicu
                        echo "<tr>
                                <td> $mjesto</td>
                                <td>$ime $prezime</td>
                                <td>$stanicaId</td>
                                <td>$vp</td>
                                <td>$trajanjeFormatirano</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>Nema rezultata za stanicu s ID-om: $stanicaId</td></tr>";
                }
            }
            
            echo "</table>";
        } else {
            echo "<p>Nema stanica za ovo natjecanje.</p>";
        }
    } else {
        echo "<p>Nije moguće dohvatiti vrijeme starta natjecanja.</p>";
    }
} else {
    echo "<p>Nije odabrano natjecanje.</p>";
}
?>

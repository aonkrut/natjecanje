<?php
require_once '../spajanje.php';

if (isset($_GET['id'])) {
    $natjecanjeId = $_GET['id'];
    
    // Fetch competition details
    $natjecanjeQuery = "SELECT * FROM natjecanje WHERE id = $natjecanjeId";
    $natjecanjeResult = $conn->query($natjecanjeQuery);
    $natjecanje = $natjecanjeResult->fetch_assoc();

    // Fetch competitors
    $natjecateljiQuery = "SELECT * FROM natjecatelji ";
    $natjecateljiResult = $conn->query($natjecateljiQuery);

    // Fetch checkpoints
    $staniceQuery = "SELECT * FROM stanice WHERE natjecanje_id = $natjecanjeId";
    $staniceResult = $conn->query($staniceQuery);
}
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Natjecanje Detalji</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<div class="container mt-5">
    <h1>Natjecanje: <?php echo $natjecanje['naziv']; ?></h1>
    <p>Datum Održavanja: <?php echo $natjecanje['datum_odrzavanja']; ?></p>
    <p>Vrijeme Starta: <?php echo $natjecanje['vrijeme_starta']; ?></p>

    <h2>Prijavljeni Natjecatelji</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Email</th>
                <th>Ime</th>
                <th>Prezime</th>
                <th>Godina Rođenja</th>
                <th>Klub</th>
                <th>Kategorija</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $natjecateljiResult->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['ime']; ?></td>
                    <td><?php echo $row['prezime']; ?></td>
                    <td><?php echo $row['god_rodenja']; ?></td>
                    <td><?php echo $row['klub']; ?></td>
                    <td><?php echo $row['kategorija']; ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <h2>Stanice</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Naziv</th>
                <th>Lozinka</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $staniceResult->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['naziv']; ?></td>
                    <td><?php echo $row['lozinka']; ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

   

    <a href="rezultati.php?id=<?php echo $natjecanjeId; ?>" class="btn btn-info mt-3">Prikaži Rezultate</a>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0/js/bootstrap.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>

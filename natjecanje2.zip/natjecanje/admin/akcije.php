<?php
include '../spajanje.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'addNatjecanje':
                $naziv = $_POST['naziv'];
                $datum_odrzavanja = $_POST['datum_odrzavanja'];
                $vrijeme_starta = $_POST['vrijeme_starta'];
                $query = "INSERT INTO natjecanje (naziv, datum_odrzavanja, vrijeme_starta) VALUES ('$naziv', '$datum_odrzavanja', '$vrijeme_starta')";
                $conn->query($query);
                break;
            case 'editNatjecanje':
                $id = $_POST['id'];
                $naziv = $_POST['naziv'];
                $datum_odrzavanja = $_POST['datum_odrzavanja'];
                $vrijeme_starta = $_POST['vrijeme_starta'];
                $query = "UPDATE natjecanje SET naziv='$naziv', datum_odrzavanja='$datum_odrzavanja', vrijeme_starta='$vrijeme_starta' WHERE id=$id";
                $conn->query($query);
                break;
            case 'deleteNatjecanje':
                $id = $_POST['id'];
                $query = "DELETE FROM natjecanje WHERE id=$id";
                $conn->query($query);
                break;
            case 'addNatjecatelj':
                $ime = $_POST['ime'];
                $prezime = $_POST['prezime'];
                $razred_id = $_POST['razred_id'];
                $kategorija = $_POST['kategorija'];
                $spol = $_POST['spol'];
                $query = "INSERT INTO natjecatelji (ime, prezime, razred_id, kategorija, spol) VALUES ('$ime', '$prezime', '$razred_id', '$kategorija', '$spol')";
                $conn->query($query);
                break;
            case 'editNatjecatelj':
                $id = $_POST['id'];
                $ime = $_POST['ime'];
                $prezime = $_POST['prezime'];
                $razred_id = $_POST['razred_id'];
                $kategorija = $_POST['kategorija'];
                $spol = $_POST['spol'];
                $query = "UPDATE natjecatelji SET ime='$ime', prezime='$prezime', razred_id='$razred_id', kategorija='$kategorija', spol='$spol' WHERE id=$id";
                $conn->query($query);
                break;
            case 'deleteNatjecatelj':
                $id = $_POST['id'];
                $query = "DELETE FROM natjecatelji WHERE id=$id";
                $conn->query($query);
                break;
            case 'addStanica':
                $naziv = $_POST['naziv'];
                $natjecanje_id = $_POST['natjecanje_id'];
                $lozinka = $_POST['lozinka'];
                $query = "INSERT INTO stanice (naziv, natjecanje_id, lozinka) VALUES ('$naziv', '$natjecanje_id', '$lozinka')";
                $conn->query($query);
                break;
            case 'editStanica':
                $id = $_POST['id'];
                $naziv = $_POST['naziv'];
                $natjecanje_id = $_POST['natjecanje_id'];
                $lozinka = $_POST['lozinka'];
                $query = "UPDATE stanice SET naziv='$naziv', natjecanje_id='$natjecanje_id', lozinka='$lozinka' WHERE id=$id";
                $conn->query($query);
                break;
            case 'deleteStanica':
                $id = $_POST['id'];
                $query = "DELETE FROM stanice WHERE id=$id";
                $conn->query($query);
                break;
        }
    }
}

$conn->close();
header("Location: index.php");
exit();
?>

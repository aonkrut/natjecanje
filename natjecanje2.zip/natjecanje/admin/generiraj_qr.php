<?php
include '../spajanje.php';
require_once 'fpdf/fpdf.php';

if (isset($_POST['natjecatelj_id'])) {
    $natjecateljId = $_POST['natjecatelj_id'];

    // Fetch competitors from database if id is provided
    $natjecateljiQuery = "SELECT * FROM natjecatelji WHERE id = $natjecateljId";
    $natjecateljiResult = $conn->query($natjecateljiQuery);

    // Initialize PDF
    $pdf = new FPDF();
    $pdf->AddPage();

    while ($row = $natjecateljiResult->fetch_assoc()) {
        $natjecateljId = $row['id'];
        $imePrezime = $row['ime'] . ' ' . $row['prezime'];
        $qrContent = "$natjecateljId";
        
        // Generate QR Code from web service
        $qrFileName = "qr_$natjecateljId.png";
        file_put_contents("../qr_kodovi/$qrFileName", file_get_contents("https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=$qrContent"));
        

        // Add name above QR Code
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, $imePrezime, 0, 1);
        $pdf->Image("../qr_kodovi/$qrFileName", 10, $pdf->GetY() + 10, 40, 40);
        $pdf->Ln(60);

        // Delete QR Code file after adding to PDF
        unlink("../qr_kodovi/$qrFileName");
        $pdf->Output('natjecatelj_ '.$imePrezime.'.pdf', 'D');
    }

   
   
}
 else {
    // Fetch all competitors from database
    $natjecateljiQuery = "SELECT * FROM natjecatelji";
    $natjecateljiResult = $conn->query($natjecateljiQuery);

    // Initialize PDF
    $pdf = new FPDF();
    $pdf->AddPage();

    while ($row = $natjecateljiResult->fetch_assoc()) {
        $natjecateljId = $row['id'];
        $imePrezime = $row['ime'] . ' ' . $row['prezime'];
        $qrContent = "$natjecateljId";
        
        // Generate QR Code from web service
        $qrFileName = "qr_$natjecateljId.png";
        file_put_contents("../qr_kodovi/$qrFileName", file_get_contents("https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=$qrContent"));
        

        // Add name above QR Code
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, $imePrezime, 0, 1);
        $pdf->Image("../qr_kodovi/$qrFileName", 10, $pdf->GetY() + 10, 40, 40);
        $pdf->Ln(60);

        // Delete QR Code file after adding to PDF
        unlink("../qr_kodovi/$qrFileName");
    }

    // Output PDF
    $pdf->Output('natjecatelji_qr.pdf', 'D');
}
?>

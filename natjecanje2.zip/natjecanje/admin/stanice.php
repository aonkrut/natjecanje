<?php
include '../spajanje.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM stanice WHERE id = $id";
    $result = $conn->query($query);
    $stanica = $result->fetch_assoc();
} else {
    $stanica = null;
}


$natjecanjaQuery = "SELECT * FROM natjecanje";
$natjecanjaResult = $conn->query($natjecanjaQuery);
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $stanica ? 'Uredi Stanicu' : 'Dodaj Novu Stanicu'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<link href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1><?php echo $stanica ? 'Uredi Stanicu' : 'Dodaj Novu Stanicu'; ?></h1>
    <form action="akcije.php" method="POST">
        <input type="hidden" name="action" value="<?php echo $stanica ? 'editStanica' : 'addStanica'; ?>">
        <?php if ($stanica) { ?>
            <input type="hidden" name="id" value="<?php echo $stanica['id']; ?>">
        <?php } ?>
        <div class="mb-3">
            <label for="naziv" class="form-label">Naziv</label>
            <input type="text" class="form-control" id="naziv" name="naziv" value="<?php echo $stanica ? $stanica['naziv'] : ''; ?>" required>
        </div>
        <div class="mb-3">
            <label for="natjecanje_id" class="form-label">Natjecanje</label>
            <select class="form-control" id="natjecanje_id" name="natjecanje_id" required>
                <?php while ($row = $natjecanjaResult->fetch_assoc()) { ?>
                    <option value="<?php echo $row['id']; ?>" <?php echo $stanica && $stanica['natjecanje_id'] == $row['id'] ? 'selected' : ''; ?>>
                        <?php echo $row['naziv']; ?>
                    </option>
                <?php } ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="lozinka" class="form-label">Lozinka</label>
            <input type="password" class="form-control" id="lozinka" name="lozinka" value="<?php echo $stanica ? $stanica['lozinka'] : ''; ?>" required>
        </div>
        <button type="submit" class="btn btn-primary"><?php echo $stanica ? 'Spremi Promjene' : 'Dodaj Stanicu'; ?></button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0/js/bootstrap.min.js"></script>
</body>
</html>

<?php $conn->close(); ?>

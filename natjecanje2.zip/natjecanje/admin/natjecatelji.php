<?php
include '../spajanje.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM natjecatelji WHERE id = $id";
    $result = $conn->query($query);
    $natjecatelj = $result->fetch_assoc();
} else {
    $natjecatelj = null;
}

// Dohvatiti sve razrede
$razredQuery = "SELECT * FROM razred";
$razredResult = $conn->query($razredQuery);

// Dohvatiti sve kategorije
$kategorijeQuery = "SELECT * FROM kategorije";
$kategorijeResult = $conn->query($kategorijeQuery);
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $natjecatelj ? 'Uredi Natjecatelja' : 'Dodaj Novog Natjecatelja'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3yAZprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<div class="container mt-5">
    <h1><?php echo $natjecatelj ? 'Uredi Natjecatelja' : 'Dodaj Novog Natjecatelja'; ?></h1>
    <form action="akcije.php" method="POST">
        <input type="hidden" name="action" value="<?php echo $natjecatelj ? 'editNatjecatelj' : 'addNatjecatelj'; ?>">
        <?php if ($natjecatelj) { ?>
            <input type="hidden" name="id" value="<?php echo $natjecatelj['id']; ?>">
        <?php } ?>
        <div class="mb-3">
            <label for="ime" class="form-label">Ime</label>
            <input type="text" class="form-control" id="ime" name="ime" value="<?php echo $natjecatelj ? $natjecatelj['ime'] : ''; ?>" required>
        </div>
        <div class="mb-3">
            <label for="prezime" class="form-label">Prezime</label>
            <input type="text" class="form-control" id="prezime" name="prezime" value="<?php echo $natjecatelj ? $natjecatelj['prezime'] : ''; ?>" required>
        </div>
        <div class="mb-3">
            <label for="razred_id" class="form-label">Razred</label>
            <select class="form-control" id="razred_id" name="razred_id" required>
                <?php while ($row = $razredResult->fetch_assoc()) { ?>
                    <option value="<?php echo $row['id']; ?>" <?php echo $natjecatelj && $natjecatelj['razred_id'] == $row['id'] ? 'selected' : ''; ?>><?php echo $row['naziv']; ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="kategorija" class="form-label">Kategorija</label>
            <select class="form-control" id="kategorija" name="kategorija" required>
                <?php while ($row = $kategorijeResult->fetch_assoc()) { ?>
                    <option value="<?php echo $row['id']; ?>" <?php echo $natjecatelj && $natjecatelj['kategorija'] == $row['id'] ? 'selected' : ''; ?>><?php echo $row['naziv']; ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="spol" class="form-label">Spol</label>
            <select class="form-control" id="spol" name="spol" required>
                <option value="1" <?php echo $natjecatelj && $natjecatelj['spol'] == 1 ? 'selected' : ''; ?>>Muško</option>
                <option value="0" <?php echo $natjecatelj && $natjecatelj['spol'] == 0 ? 'selected' : ''; ?>>Žensko</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary"><?php echo $natjecatelj ? 'Spremi Promjene' : 'Dodaj Natjecatelja'; ?></button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0/js/bootstrap.min.js"></script>
</body>
</html>

<?php $conn->close(); ?>

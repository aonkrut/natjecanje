<?php
include '../spajanje.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $naziv = $_POST['naziv'];

    $stmt = $conn->prepare("INSERT INTO razred (naziv) VALUES (?)");
    $stmt->bind_param("s", $naziv);

    if ($stmt->execute()) {
        echo "Razred uspješno dodan!";
    } else {
        echo "Greška pri dodavanju razreda: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

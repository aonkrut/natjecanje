<?php
if (isset($_POST['submit'])) {
    $fileName = $_FILES['file']['tmp_name'];

    if ($_FILES['file']['size'] > 0) {
        $file = fopen($fileName, 'r');

        echo '<h2>Popis učenika</h2>';
        echo '<table border="1">';
        echo '<tr><th>R. br.</th><th>Prezime</th><th>Ime</th><th>Spol</th><th>Zanimanje</th></tr>';

        // Skip the header row
        $header = fgetcsv($file, 0, ';');

        // Read each row and display it in the table
        while (($row = fgetcsv($file, 0, ';')) !== FALSE) {
            echo '<tr>';
            foreach ($row as $cell) {
                echo '<td>' . htmlspecialchars($cell) . '</td>';
            }
            echo '</tr>';
        }

        echo '</table>';

        fclose($file);
    } else {
        echo 'Datoteka je prazna.';
    }
} else {
    echo 'Nijedna datoteka nije odabrana.';
}
?>

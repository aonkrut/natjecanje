<?php
include '../spajanje.php';

$searchNatjecanja = isset($_GET['searchNatjecanja']) ? $_GET['searchNatjecanja'] : '';
$searchNatjecatelji = isset($_GET['searchNatjecatelji']) ? $_GET['searchNatjecatelji'] : '';
$searchStanice = isset($_GET['searchStanice']) ? $_GET['searchStanice'] : '';

$natjecanjaQuery = "SELECT * FROM natjecanje WHERE naziv LIKE '%$searchNatjecanja%'";
$natjecanjaResult = $conn->query($natjecanjaQuery);

$natjecateljiQuery = "SELECT * FROM natjecatelji WHERE ime LIKE '%$searchNatjecatelji%' OR prezime LIKE '%$searchNatjecatelji%'";
$natjecateljiResult = $conn->query($natjecateljiQuery);

$staniceQuery = "SELECT * FROM stanice WHERE naziv LIKE '%$searchStanice%'";
$staniceResult = $conn->query($staniceQuery);
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        .row {
            display: flex;
        }
        .column {
            flex: 33.33%;
            padding: 10px;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<body>
<div class="container mt-5">
    <h1>Admin Dashboard</h1>
    <div class="row">
        <!-- Natjecanja Column -->
        <div class="column">
        <div class="d-flex">
            <h2>Sva natjecanja</h2>
            <button type="button" class="btn btn-link mb-3" data-bs-toggle="modal" data-bs-target="#dodajNatjecanjeModal">Dodaj Novo Natjecanje</button>
            </div>
           
            <form method="GET" action="index.php">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="searchNatjecanja" placeholder="Pretraži natjecanja" value="<?php echo $searchNatjecanja; ?>">
                    <button class="btn btn-primary" type="submit">Pretraži</button>
                </div>
            </form>
            
            
            <!-- Modal za dodavanje novog natjecanja -->
            <div class="modal fade" id="dodajNatjecanjeModal" tabindex="-1" aria-labelledby="dodajNatjecanjeModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="dodajNatjecanjeModalLabel">Dodaj Novo Natjecanje</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="akcije.php" method="POST">
                                <input type="hidden" name="action" value="addNatjecanje">
                                <div class="mb-3">
                                    <label for="naziv" class="form-label">Naziv natjecanja:</label>
                                    <input type="text" class="form-control" id="naziv" name="naziv" required>
                                </div>
                                <div class="mb-3">
                                    <label for="datum_odrzavanja" class="form-label">Datum održavanja:</label>
                                    <input type="date" class="form-control" id="datum_odrzavanja" name="datum_odrzavanja" required>
                                </div>
                                <div class="mb-3">
                                    <label for="vrijeme_starta" class="form-label">Vrijeme početka:</label>
                                    <input type="datetime" class="form-control" id="vrijeme_starta" name="vrijeme_starta" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Dodaj Natjecanje</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Naziv</th>
                        <th>Datum Održavanja</th>
                        <th>Vrijeme Starta</th>
                        <th>Akcije</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $natjecanjaResult->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['naziv']; ?></td>
                            <td><?php echo $row['datum_odrzavanja']; ?></td>
                            <td><?php echo $row['vrijeme_starta']; ?></td>
                            <td>
                                <a href="natjecanja.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Uredi</a>
                                <form action="akcije.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="deleteNatjecanje">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Obriši</button>
                                </form>
                                <a href="rezultati.php?natjecanje_id=<?php echo $row['id']; ?>" class="btn btn-info btn-sm">Rezultati</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

     
        <!-- Stanice Column -->
        <div class="column">
        <div class="d-flex">
            <h2>Sve stanice</h2>
            <a href="stanice.php" class="btn btn-link mb-3">Dodaj Novu Stanicu</a>

            </div>
            <form method="GET" action="index.php">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="searchStanice" placeholder="Pretraži stanice" value="<?php echo $searchStanice; ?>">
                    <button class="btn btn-primary" type="submit">Pretraži</button>
                </div>
            </form>
            
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Naziv</th>
                        <th>Natjecanje ID</th>
                        <th>Kamera</th>
                        <th>Uredi</th>
                        <th>Obriši</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $staniceResult->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['naziv']; ?></td>
                            <td><?php echo $row['natjecanje_id']; ?></td>
                            <td>
                                <a href="../stanica/kamera.php?stanica_id=<?php echo $row['id'];?>">Pokreni</a>
                            </td>
                            <td>
                                <a href="stanice.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Uredi</a>
                                </td><td>
                                <form action="akcije.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="deleteStanica">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Obriši</button>
                                </form>
                            </td>
                         
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <h3>Dodaj Razred</h3>
    <form action="insert_class.php" method="post">
        <label for="naziv">Naziv razreda:</label>
        <input type="text" name="naziv" id="naziv" required>
        <button type="submit">Dodaj</button>
    </form>
   <!-- Natjecatelji Column -->
   <div class="column">
        <div class="d-flex">
            <h2>Svi natjecatelji</h2>
            <a href="natjecatelji.php" class="btn btn-link mb-3">Dodaj Novog Natjecatelja</a>
        </div>
        <form method="GET" action="index.php">
            <div class="input-group mb-3">
                <input type="text" class="form-control" name="searchNatjecatelji" placeholder="Pretraži natjecatelje" value="<?php echo $searchNatjecatelji; ?>">
                <button class="btn btn-primary" type="submit">Pretraži</button>
            </div>
        </form>
        <form action="generiraj_qr.php" method="POST">
            <input type="hidden" name="natjecanje_id" value="<?php echo $natjecanjeId; ?>">
            <button type="submit" class="btn btn-success">Generiraj QR kodove</button>
        </form>
        
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Ime</th>
                    <th>Prezime</th>
                    <th>Razred</th>
                    <th>Kategorija</th>
                    <th>Spol</th>
                    <th>Uredi</th>
                    <th>Obriši</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $natjecateljiResult->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['ime']; ?></td>
                        <td><?php echo $row['prezime']; ?></td>
                        <td><?php echo $row['razred_id']; ?></td>
                        <td><?php echo $row['kategorija']; ?></td>
                        <td><?php echo $row['spol'] == 1 ? 'Muško' : 'Žensko'; ?></td>
                        <td>
                            <a href="natjecatelji.php?id=<?php echo $row['id']; ?>" class="btn btn-info">Uredi</a>
                        </td>
                        <td>
                           <!-- <a href="akcije.php?id=<?php //echo $row['id']akcija: deleteNatjecanje; ?>" class="btn btn-danger">Obriši</a>-->
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
        </div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0/js/bootstrap.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>

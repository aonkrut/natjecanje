<?php
include '../spajanje.php';

// Provjera je li stanica_id dostupan u URL-u
if (isset($_GET['stanica_id'])) {
    $stanica_id = $_GET['stanica_id'];

    // Provjera postoji li stanica s navedenim ID-om
    $stanicaQuery = "SELECT * FROM stanice WHERE id = $stanica_id";
    $stanicaResult = $conn->query($stanicaQuery);
    //dohvaćanje naziva stanica i naziva natjecanja
    $stanica = $stanicaResult->fetch_assoc();
    $stanica_naziv = $stanica['naziv'];
   

    if ($stanicaResult->num_rows > 0) {
        // Stanica postoji, možemo prikazati QR skener
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Kamera skener</title>
    <style>
        #qr-reader {
            width: 100%;
            max-width: 600px;
            margin: auto;
        }
    </style>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- Include html5-qrcode library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5-qrcode/2.3.8/html5-qrcode.min.js"></script>
</head>
<body>
<div class="container">
    <div class="text-center">
        <h1>Stanica: <?php echo $stanica_naziv; ?></h1>
        <h2>Skenirajte QR kod</h2>
    </div>
</div>

    <div id="qr-reader"></div>
    
    <script>
        function onScanSuccess(decodedText, decodedResult) {
           //traži odbrenje za prihvat rezultata u alertu
            if (!confirm(`Došao natjecatelj s brojem: ${decodedText}. Želite li potvrditi dolazak?`)) {
                return;
            }
            
            let stanicaId = <?php echo $stanica_id; ?>;
            let natjecateljId = decodedText;
            let trenutnoVrijeme = new Date().toISOString().slice(0, 19).replace('T', ' ');
            let url = `spremi_vrijeme.php?stanica_id=${stanicaId}&natjecatelj_id=${natjecateljId}&vrijeme=${trenutnoVrijeme}`;
            fetch(url)
                .then(response => response.text())
                .then(data => {
                    console.log(data);
                    wait (1000);
                    html5QrCode.start();
                })
                .catch(error => {
                    console.error(`Error: ${error}`);
                });
            
        }

        function onScanFailure(error) {
            
            console.warn(`QR code scan error: ${error}`);
        }

        // Inicijaliziraj QR kôd skener
        const html5QrCode = new Html5Qrcode("qr-reader");

        // Pokreni skener
        html5QrCode.start(
            { facingMode: "environment" }, // postavke kamere
            {
                fps: 10, // frekvencija snimanja u sekundi
                qrbox: { width: 250, height: 250 } // veličina prozora za skeniranje
            },
            onScanSuccess,
            onScanFailure
        ).catch(err => {
            console.error(`Unable to start scanning, error: ${err}`);
        });
    </script>
</body>
</html>

<?php
    } else {
        // Ako stanica s navedenim ID-om ne postoji, prikaži poruku greške
        echo "Stanica s navedenim ID-om ne postoji.";
    }
} else {
    // Ako stanica_id nije dostupan u URL-u, prikaži poruku greške
    echo "Nedostaje stanica_id u URL-u.";
}
?>

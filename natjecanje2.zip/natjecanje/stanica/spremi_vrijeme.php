<?php 
//čitanje   podataka iz URL-a let url = `spremi_vrijeme.php?stanica_id=${stanicaId}&natjecatelj_id=${natjecateljId}&vrijeme=${trenutnoVrijeme}`;
$stanica_id = $_GET['stanica_id'];
$natjecatelj_id = $_GET['natjecatelj_id'];
$vrijeme = $_GET['vrijeme'];

// Uspostavljanje veze s bazom podataka
include '../spajanje.php'; // Sadrži $conn = new mysqli(...)
// Spremanje vremena u bazu podataka
$spremiVrijemeQuery = "INSERT INTO rezultati (stanica_id, natjecatelj_id, vrijeme_potvrde) VALUES ($stanica_id, $natjecatelj_id, '$vrijeme')";
$conn->query($spremiVrijemeQuery);
if ($conn->error) {
    echo "Error: " . $conn->error;
} else {
    echo "Vrijeme uspješno spremljeno!";
    //header("Location: kamera.php?stanica_id=$stanica_id");
}

?>